<?php

namespace App\Http\Controllers\Admin;

use App\Models\Stay;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Controller;

class StayController extends Controller
{
    // Tampilkan daftar stays
    public function index()
    {
        $stays = Stay::all();
        return view('stays.index', compact('stays'));
    }

    // Tampilkan form tambah stay
    public function create()
    {
        return view('stays.create');
    }

    // Simpan stay baru
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'location' => 'required',
            'price' => 'required|numeric',
            'type' => 'required', // hotel, guesthouse, etc.
            'rating' => 'required|numeric|min:0|max:5',
            'description' => 'required',
            'image_file' => 'nullable|image|max:2048',
        ]);

        $imagePath = null;
        if ($request->hasFile('image_file')) {
            $imagePath = $request->file('image_file')->store('images/stays', 'public');
        }

        Stay::create([
            'name' => $request->name,
            'location' => $request->location,
            'price' => $request->price,
            'type' => $request->type,
            'rating' => $request->rating,
            'description' => $request->description,
            'image_url' => $imagePath,
            'id_destinations' => $request->id_destinations, // jika stay terkait destinasi
        ]);

        return redirect()->route('stays.index')->with('success', 'Stay added successfully.');
    }

    // Tampilkan form edit stay
    public function edit($id)
    {
        $stay = Stay::findOrFail($id);
        return view('stays.edit', compact('stay'));
    }

    // Update stay
    public function update(Request $request, $id)
    {
        $stay = Stay::findOrFail($id);

        $request->validate([
            'name' => 'required',
            'location' => 'required',
            'price' => 'required|numeric',
            'type' => 'required',
            'rating' => 'required|numeric|min:0|max:5',
            'description' => 'required',
            'image_file' => 'nullable|image|max:2048',
        ]);

        $imagePath = $stay->image_url;
        if ($request->hasFile('image_file')) {
            $imagePath = $request->file('image_file')->store('images/stays', 'public');
        }

        $stay->update([
            'name' => $request->name,
            'location' => $request->location,
            'price' => $request->price,
            'type' => $request->type,
            'rating' => $request->rating,
            'description' => $request->description,
            'image_url' => $imagePath,
        ]);

        return redirect()->route('stays.index')->with('success', 'Stay updated successfully.');
    }

    // Hapus stay
    public function destroy($id)
    {
        $stay = Stay::findOrFail($id);
        $stay->delete();
        return redirect()->route('stays.index')->with('success', 'Stay deleted successfully.');
    }
}
