@extends('layouts.mainheader')

@section('content')
<div class="container mt-5">
    <h1>Edit Culinary</h1>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('Admin.culinaries.update', $culinary->id_culinaries) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="form-group mb-3">
            <label for="name">Name</label>
            <input type="text" name="name" class="form-control" value="{{ old('name', $culinary->name) }}" required>
        </div>

        <div class="form-group mb-3">
            <label for="location">Location</label>
            <input type="text" name="location" class="form-control" value="{{ old('location', $culinary->location) }}" required>
        </div>

        <div class="form-group mb-3">
            <label for="price_range">Price Range</label>
            <select name="price_range" class="form-control" required>
                <option value="low" {{ old('price_range', $culinary->price_range) == 'low' ? 'selected' : '' }}>Low</option>
                <option value="medium" {{ old('price_range', $culinary->price_range) == 'medium' ? 'selected' : '' }}>Medium</option>
                <option value="high" {{ old('price_range', $culinary->price_range) == 'high' ? 'selected' : '' }}>High</option>
            </select>
        </div>

        <div class="form-group mb-3">
            <label for="rating">Rating (e.g. 4.5)</label>
            <input type="number" step="0.01" name="rating" class="form-control" value="{{ old('rating', $culinary->rating) }}" required>
        </div>

        <div class="form-group mb-3">
            <label for="cuisine_type">Cuisine Type</label>
            <input type="text" name="cuisine_type" class="form-control" value="{{ old('cuisine_type', $culinary->cuisine_type) }}" required>
        </div>

        <div class="form-group mb-3">
            <label for="description">Description</label>
            <textarea name="description" rows="3" class="form-control">{{ old('description', $culinary->description) }}</textarea>
        </div>

        <div class="form-group mb-3">
            <label>Current Image</label><br>
            @if ($culinary->image_url)
                <img src="{{ asset('storage/' . $culinary->image_url) }}" alt="Current Image" style="max-width: 150px;">
            @else
                No Image
            @endif
        </div>

        <div class="form-group mb-3">
            <label for="image_file">Change Image (optional)</label>
            <input type="file" name="image_file" class="form-control" accept="image/*">
        </div>

        <button type="submit" class="btn btn-primary">Update Culinary</button>
        <a href="{{ route('Admin.culinaries.index') }}" class="btn btn-secondary">Back</a>
    </form>
</div>
@endsection
